#!/bin/bash
#
# Skripta za brisanje fajlova sa zadatom ekstenzijom koji su stariji od zadatih broja dana.
# Varijable:
#	date1 		- broj dana prema kome se pretrazuju i brisu fajlovi; mora da ima + znak ispred broja dana.
#	filename_ext 	- ekstenzija fajlova koji se brisu.
#	log 		- fajl u koji se smesta log koji fajlovi su se obrisali
#	mail_report 	- mail na koji se salje report o brisanju sa fajlovima koji su se obrisali

date1="+10"
folder_path=""
filename_ext="xls"
log="delete_log.txt"
mail_report="neko@bancaintesa.rs"
date2=${date1#*+}

rm $log

while IFS='' read -r folder_path || [[ -n "$folder_path" ]]; do
	echo "### Brisanje fajlova sa ekstenzijom .$filename_ext iz foldera $folder_path starijih od $date2 dana." >> $log
	find $folder_path -name "*.$filename_ext" -type f -maxdepth 1 -mtime $date1 -print -delete >> $log
done < "folders.txt"

cat $log | mail -s "Report o brisanju fajlova..." $mail_report