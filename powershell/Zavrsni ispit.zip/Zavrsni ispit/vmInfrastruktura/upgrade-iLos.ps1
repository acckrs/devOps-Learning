
[CmdletBinding()]
param (
    #Imena servera razdvojena ','
    [String[]] $Servers,
    #Putanja do bin-a
    [String] $binPath = "C:\Acca\Powershell_local\BIB\iLO_upgrade\ilo4_255.bin"
)
 
function find-HPiLOversions {
    $ilos = @()
    foreach ($server in $servers) {
        $ilo = Get-HPiLOFirmwareVersion -Server $Server -Username Administrator -Password Simfuj5! -DisableCertificateAuthentication
        $props = @{
            "IP"               = $ilo.IP;
            "Hostname"         = $ilo.Hostname;
            "Mgmt processor"   = $ilo.MANAGEMENT_PROCESSOR;
            "Firmware version" = $ilo.firmware_version;
            "Firmware date"    = $ilo.FIRMWARE_DATE;
            "License type"     = $ilo.LICENSE_TYPE
        }
        $obj = New-Object -Type psobject -Property $props
        $ilos += $obj
    }
    Write-Output $ilos
}
function update-HPiLO {
    foreach ($server in $servers) {
    
        Update-HPiLOFirmware -Server $Server -Username Administrator -Password Simfuj5! -TPMEnabled -Location $binPath -DisableCertificateAuthentication
    }
}

find-HPiLOversions
#update-HPiLO
